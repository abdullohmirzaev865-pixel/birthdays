# Birthdays APK
1. GitHub'da yangi repo oching va shu fayllarni yuklang (.github papkasi bilan).
2. Repo > Actions > "Build APK" > Run workflow.
3. 3-5 daqiqadan so'ng Artifacts bo'limidan birthdays-apk ni yuklab oling (ichida app-debug.apk).
4. APK'ni telefonga o'tkazib o'rnating ("noma'lum manbalardan o'rnatish"ga ruxsat bering).
